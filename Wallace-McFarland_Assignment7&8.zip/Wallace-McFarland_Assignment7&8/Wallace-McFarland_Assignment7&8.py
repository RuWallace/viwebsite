import pandas as pd
import plotly.express as px
import dash
from dash import Dash, html, Input, Output, dcc
import dash_bootstrap_components as dbc

data = pd.read_csv('assets\\cpugpu.csv')
data.columns.tolist()
tf = px.scatter(data, x='transistors(million)', y='frequency(million)', trendline="ols")
tdpf = px.scatter(data, x='transistors(million)', y='tdp(w)', trendline="ols")
td = px.scatter(data, x='transistors(million)', y='diesize(mm)', trendline="ols")

tf.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                 yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                 plot_bgcolor='white')
tdpf.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                   yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                   plot_bgcolor='white')
td.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                 yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                 plot_bgcolor='white')

gpuf = px.scatter(data, x='transistors(million)1', y='frequency(million)1',trendline="ols")
gputdp = px.scatter(data, x='transistors(million)1', y='tdp(w)1',trendline="ols")
gpud = px.scatter(data, x='transistors(million)1', y='diesize(mm)1',trendline="ols")

gpuf.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                 yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                 plot_bgcolor='white')
gputdp.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                   yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                   plot_bgcolor='white')
gpud.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                 yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                 plot_bgcolor='white')

app = Dash(external_stylesheets=[dbc.themes.CYBORG], use_pages=True)

graphs = dbc.Row(
    children=[
        dbc.Col(
            children=[
                html.H1('GPU Speed', className='text-center'),
                dcc.Graph(figure=gpuf, id='plot4'),
            ],
            width=4,
        ),
        dbc.Col(
            children=[
                html.H1('GPU Power Effiency', className='text-center'),
                dcc.Graph(figure=gputdp, id='plot5'),
            ],
            width=4,
        ),
        dbc.Col(
            children=[
                html.H1('GPU Diesize', className='text-center'),
                dcc.Graph(figure=gpud, id='plot6'),
            ],
            width=4,
        ),
        dbc.Col(
            children=[
                html.H1('CPU Speed', className='text-center'),
                html.H2('Smaller transistors and different material transistors can reach higher frequencies so the same amount of transistors can have different frequencies.  Transistors are getting faster!',
                        style={'font-size': '15px'}, className='text-center'),
                dcc.Graph(figure=tf, id='plot1'),
            ],
            width=4,
        ),
        dbc.Col(
            children=[
                html.H1('CPU Power Efficiency', className='text-center'),
                html.H2('Changes in transistors can make them more power efficient so the same amount of transistors can draw less power',
                        style={'font-size': '15px'}, className='text-center'),
                dcc.Graph(figure=tdpf, id='plot2'),
            ],
            width=4,
        ),
        dbc.Col(
            children=[
                html.H1('CPU Diesize', className='text-center'),
                html.H2('As transistors shrink more are placed inside a die',
                        style={'font-size': '15px'}, className='text-center'),
                dcc.Graph(figure=td, id='plot3'),
            ],
            width=4,
        )
    ],
)

dropdown1 = dbc.Select(
    options=[
        {'label': 'Blue', 'value': 'blue'},
        {'label': 'Red', 'value': 'red'},
    ],
    value='blue',
    id='color',
)

dropdown = dbc.Select(
    options=[
        {'label': 'Show Line', 'value': 'show'},
        {'label': 'Hide Line', 'value': 'hide'},
    ],
    value='show',
    id='showhide',
)

rowmenu = dbc.Row(
    children=[
        dbc.Col(
            children=[
                dropdown,
            ],
            width=dict(size=3)
        ),
        dbc.Col(
            children=[
                dropdown1,
            ],
            width=dict(size=3)
        ),
    ],
    justify="center",
    className="m-5"
)

@app.callback(
    Output('plot1', 'figure'),
    Output('plot2', 'figure'),
    Output('plot3', 'figure'),
    Output('plot4', 'figure'),
    Output('plot5', 'figure'),
    Output('plot6', 'figure'),
    Input('showhide', 'value'),
    Input('color', 'value')
)
def update_plots(selected_option, color):
    changed_id = [p['prop_id'] for p in dash.callback_context.triggered][0]
    
    if 'showhide' in changed_id:
        if selected_option == 'show':
            tf_updated = px.scatter(data, x='transistors(million)', y='frequency(million)', trendline="ols")
            tdpf_updated = px.scatter(data, x='transistors(million)', y='tdp(w)', trendline="ols")
            td_updated = px.scatter(data, x='transistors(million)', y='diesize(mm)', trendline="ols")
            gpuf_updated = px.scatter(data, x='transistors(million)1', y='frequency(million)1',trendline="ols")
            gputdp_updated = px.scatter(data, x='transistors(million)1', y='tdp(w)1',trendline="ols")
            gpud_updated = px.scatter(data, x='transistors(million)1', y='diesize(mm)1',trendline="ols")
        else:
            tf_updated = px.scatter(data, x='transistors(million)', y='frequency(million)')
            tdpf_updated = px.scatter(data, x='transistors(million)', y='tdp(w)')
            td_updated = px.scatter(data, x='transistors(million)', y='diesize(mm)')
            gpuf_updated = px.scatter(data, x='transistors(million)1', y='frequency(million)1')
            gputdp_updated = px.scatter(data, x='transistors(million)1', y='tdp(w)1')
            gpud_updated = px.scatter(data, x='transistors(million)1', y='diesize(mm)1')
        
        
        tf_updated.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                 yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                 plot_bgcolor='white')
        tdpf_updated.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                   yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                   plot_bgcolor='white')
        td_updated.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                 yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                 plot_bgcolor='white')
        
        
        gpuf_updated.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                   yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                   plot_bgcolor='white')
        gputdp_updated.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                     yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                     plot_bgcolor='white')
        gpud_updated.update_layout(xaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                   yaxis=dict(showgrid=False, showline=True, linecolor='black'),
                                   plot_bgcolor='white')
        
        for fig in [tf_updated, tdpf_updated, td_updated, gpuf_updated, gputdp_updated, gpud_updated]:
            for trace in fig.data:
                if 'trendline' not in trace.name:
                    trace.line.color = color
        
        return tf_updated, tdpf_updated, td_updated, gpuf_updated, gputdp_updated, gpud_updated
    
    elif 'color' in changed_id:
        for fig in [tf, tdpf, td, gpuf, gputdp, gpud]:
            for trace in fig.data:
                if 'trendline' not in trace.name:
                    trace.line.color = color
        return tf, tdpf, td, gpuf, gputdp, gpud
    
source_link = html.P('Source: Kaggle - CPU and GPU Product Data', style={'text-align': 'center', 'margin-top': '2rem'})

app.layout = dbc.Container(
    children=[
        dbc.NavbarSimple(
			children=[
				dbc.NavItem( dbc.NavLink('1', href='/') ),
				dbc.NavItem( dbc.NavLink('2', href='/2') ),
			],
		),
		dash.page_container,
        html.H1('CPU & GPU Performance', style={'textAlign': 'center', 'margin': '2rem 0', 'font-size': '4rem'}),
        graphs,
        rowmenu,
        source_link,
    ]
)

if __name__ == '__main__':
    app.run_server(debug=True)