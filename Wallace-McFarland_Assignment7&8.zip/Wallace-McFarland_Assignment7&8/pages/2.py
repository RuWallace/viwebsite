import pandas as pd
import plotly.express as px
import dash
from dash import html

app = dash.Dash(__name__)

dash.register_page( __name__, path='/2')

data = pd.read_csv('assets\\cpugpu.csv')

print(data.columns)

count0 = (data['foundry'] == 'Intel').sum()
print('Intel', count0)

count1 = (data['foundry'] == 'Unknown').sum()
print('Unknown', count1)

count2 = (data['foundry'] == 'TSMC').sum()
print("TSMC", count2)

count3 = (data['foundry'] == 'GF').sum()
print("GF", count3)

count4 = (data['foundry1'] == 'Intel').sum()
print('Intel', count4)

count5 = (data['foundry1'] == 'Unknown').sum()
print('Unknown', count5)

count6 = (data['foundry1'] == 'TSMC').sum()
print("TSMC", count6)

count7 = (data['foundry1'] == 'GF').sum()
print("GF", count7)

count8 = (data['foundry1'] == 'Samsung').sum()
print("Samsung", count8)

data = {'Values': [1242, 760, 97, 93],
        'Manufacturer': ['Intel', 'Unknown', 'TSMC', 'GF']}

fig0 = px.bar(data, x='Manufacturer', y='Values', title='Cpus Produced by Company manufacturer')
barcpu = fig0.show()

data = {'Values': [148, 106, 2081, 172, 60],
        'Manufacturer': ['Intel', 'Unknown', 'TSMC', 'GF', 'Samsung']}

fig1 = px.bar(data, x='Manufacturer', y='Values', title='Gpus Produced by manufacturer')
bargpu = fig1.show()

layout = html.Div(
	children=[
		html.H1('CPUs and GPUs Produced'),
        barcpu,bargpu
	]
)

if __name__ == '__main__':
    app.run_server(debug=True)